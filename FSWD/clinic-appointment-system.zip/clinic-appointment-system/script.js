// ==================== DATA MANAGEMENT ====================
let clients = JSON.parse(localStorage.getItem('clients')) || [];
let doctors = JSON.parse(localStorage.getItem('doctors')) || [];
let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
let currentUser = null;
let currentDoctor = null;

// Initialize default admin if not exists
if (!localStorage.getItem('admin')) {
    localStorage.setItem('admin', JSON.stringify({ id: 'admin', password: '123' }));
}

// Initialize default doctors if not exists
if (doctors.length === 0) {
    const defaultDoctors = [
        { id: 1, name: 'Dr. Smith', specialization: 'Cardiologist', email: 'smith@clinic.com', password: '123', phone: '1234567890' },
        { id: 2, name: 'Dr. John', specialization: 'Dentist', email: 'john@clinic.com', password: '123', phone: '1234567891' },
        { id: 3, name: 'Dr. Priya', specialization: 'Dermatologist', email: 'priya@clinic.com', password: '123', phone: '1234567892' },
        { id: 4, name: 'Dr. Kumar', specialization: 'General Physician', email: 'kumar@clinic.com', password: '123', phone: '1234567893' }
    ];
    localStorage.setItem('doctors', JSON.stringify(defaultDoctors));
    doctors = defaultDoctors;
}

// ==================== CLIENT REGISTRATION ====================
if (document.getElementById('clientRegisterForm')) {
    document.getElementById('clientRegisterForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        if (password !== confirmPassword) {
            alert('Passwords do not match!');
            return;
        }
        
        // Check if email already exists
        if (clients.find(c => c.email === email)) {
            alert('Email already registered!');
            return;
        }
        
        const newClient = {
            id: Date.now(),
            name,
            email,
            phone,
            password
        };
        
        clients.push(newClient);
        localStorage.setItem('clients', JSON.stringify(clients));
        alert('Registration successful! Please login.');
        window.location.href = 'client-login.html';
    });
}

// ==================== CLIENT LOGIN ====================
if (document.getElementById('clientLoginForm')) {
    document.getElementById('clientLoginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        const client = clients.find(c => c.email === email && c.password === password);
        
        if (client) {
            localStorage.setItem('currentUser', JSON.stringify(client));
            window.location.href = 'client-dashboard.html';
        } else {
            alert('Invalid email or password!');
        }
    });
}

// ==================== CLIENT DASHBOARD ====================
if (window.location.pathname.includes('client-dashboard.html')) {
    currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    if (!currentUser) {
        window.location.href = 'client-login.html';
    }
    
    document.getElementById('userName').innerHTML = `Welcome, ${currentUser.name}`;
    displayClientAppointments();
    
    // Book Appointment
    document.getElementById('appointmentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const appointment = {
            id: Date.now(),
            clientId: currentUser.id,
            clientName: currentUser.name,
            clientEmail: currentUser.email,
            clientPhone: currentUser.phone,
            doctor: document.getElementById('doctor').value,
            doctorName: document.getElementById('doctor').value.split(' - ')[0],
            date: document.getElementById('date').value,
            time: document.getElementById('time').value,
            reason: document.getElementById('reason').value,
            status: 'Pending',
            createdAt: new Date().toISOString()
        };
        
        appointments.push(appointment);
        localStorage.setItem('appointments', JSON.stringify(appointments));
        alert('Appointment booked successfully!');
        document.getElementById('appointmentForm').reset();
        displayClientAppointments();
    });
}

function displayClientAppointments() {
    const clientAppointments = appointments.filter(a => a.clientId === currentUser.id);
    const container = document.getElementById('appointmentsList');
    
    if (clientAppointments.length === 0) {
        container.innerHTML = '<div class="alert alert-info">No appointments found. Book your first appointment!</div>';
        return;
    }
    
    container.innerHTML = clientAppointments.map(app => `
        <div class="appointment-card card mb-3" style="border-left-color: ${getStatusColor(app.status)}">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="mb-2">Doctor: ${app.doctor}</h6>
                        <p class="mb-1"><strong>Date:</strong> ${app.date}</p>
                        <p class="mb-1"><strong>Time:</strong> ${app.time}</p>
                        <p class="mb-1"><strong>Reason:</strong> ${app.reason || 'Not specified'}</p>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <span class="badge status-${app.status.toLowerCase()}">${app.status}</span>
                        ${app.status === 'Accept' ? '<p class="mt-2 text-success mb-0"><small>✓ Appointment confirmed by doctor</small></p>' : ''}
                        ${app.status === 'Reject' ? '<p class="mt-2 text-danger mb-0"><small>✗ Appointment rejected by doctor</small></p>' : ''}
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

// ==================== ADMIN LOGIN ====================
if (document.getElementById('adminLoginForm')) {
    document.getElementById('adminLoginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const adminId = document.getElementById('adminId').value;
        const adminPassword = document.getElementById('adminPassword').value;
        const admin = JSON.parse(localStorage.getItem('admin'));
        
        if (adminId === admin.id && adminPassword === admin.password) {
            localStorage.setItem('isAdminLoggedIn', 'true');
            window.location.href = 'admin-dashboard.html';
        } else {
            alert('Invalid Admin ID or Password!');
        }
    });
}

// ==================== ADMIN DASHBOARD ====================
if (window.location.pathname.includes('admin-dashboard.html')) {
    if (!localStorage.getItem('isAdminLoggedIn')) {
        window.location.href = 'admin-login.html';
    }
    
    displayClients();
    displayDoctors();
    displayAllAppointments();
}

function displayClients() {
    const clients = JSON.parse(localStorage.getItem('clients')) || [];
    const container = document.getElementById('clientsList');
    
    if (clients.length === 0) {
        container.innerHTML = '<div class="alert alert-info">No clients registered yet.</div>';
        return;
    }
    
    container.innerHTML = `
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Action</th></tr>
                </thead>
                <tbody>
                    ${clients.map(client => `
                        <tr>
                            <td>${client.id}</td>
                            <td>${client.name}</td>
                            <td>${client.email}</td>
                            <td>${client.phone}</td>
                            <td><button class="btn btn-danger btn-sm" onclick="deleteClient(${client.id})">Delete</button></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function displayDoctors() {
    const doctors = JSON.parse(localStorage.getItem('doctors')) || [];
    const container = document.getElementById('doctorsList');
    
    if (doctors.length === 0) {
        container.innerHTML = '<div class="alert alert-info">No doctors added yet.</div>';
        return;
    }
    
    container.innerHTML = `
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr><th>ID</th><th>Name</th><th>Specialization</th><th>Email</th><th>Phone</th><th>Action</th></tr>
                </thead>
                <tbody>
                    ${doctors.map(doctor => `
                        <tr>
                            <td>${doctor.id}</td>
                            <td>${doctor.name}</td>
                            <td>${doctor.specialization}</td>
                            <td>${doctor.email}</td>
                            <td>${doctor.phone}</td>
                            <td><button class="btn btn-danger btn-sm" onclick="deleteDoctor(${doctor.id})">Delete</button></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function displayAllAppointments() {
    const appointments = JSON.parse(localStorage.getItem('appointments')) || [];
    const container = document.getElementById('allAppointments');
    
    if (appointments.length === 0) {
        container.innerHTML = '<div class="alert alert-info">No appointments booked yet.</div>';
        return;
    }
    
    container.innerHTML = `
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th><th>Client</th><th>Doctor</th><th>Date</th><th>Time</th><th>Status</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${appointments.map(app => `
                        <tr>
                            <td>${app.id}</td>
                            <td>${app.clientName}</td>
                            <td>${app.doctor}</td>
                            <td>${app.date}</td>
                            <td>${app.time}</td>
                            <td><span class="badge status-${app.status.toLowerCase()}">${app.status}</span></td>
                            <td><button class="btn btn-danger btn-sm" onclick="deleteAppointment(${app.id})">Delete</button></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function deleteClient(id) {
    if (confirm('Delete this client?')) {
        let clients = JSON.parse(localStorage.getItem('clients'));
        clients = clients.filter(c => c.id !== id);
        localStorage.setItem('clients', JSON.stringify(clients));
        displayClients();
    }
}

function deleteDoctor(id) {
    if (confirm('Delete this doctor?')) {
        let doctors = JSON.parse(localStorage.getItem('doctors'));
        doctors = doctors.filter(d => d.id !== id);
        localStorage.setItem('doctors', JSON.stringify(doctors));
        displayDoctors();
    }
}

function deleteAppointment(id) {
    if (confirm('Delete this appointment?')) {
        let appointments = JSON.parse(localStorage.getItem('appointments'));
        appointments = appointments.filter(a => a.id !== id);
        localStorage.setItem('appointments', JSON.stringify(appointments));
        displayAllAppointments();
    }
}

function addDoctor() {
    const modal = new bootstrap.Modal(document.getElementById('addDoctorModal'));
    modal.show();
}

function saveDoctor() {
    const doctors = JSON.parse(localStorage.getItem('doctors')) || [];
    const newDoctor = {
        id: Date.now(),
        name: document.getElementById('docName').value,
        specialization: document.getElementById('docSpecialization').value,
        email: document.getElementById('docEmail').value,
        phone: document.getElementById('docPhone').value,
        password: '123'
    };
    
    doctors.push(newDoctor);
    localStorage.setItem('doctors', JSON.stringify(doctors));
    alert('Doctor added successfully!');
    location.reload();
}

// ==================== DOCTOR LOGIN ====================
if (document.getElementById('doctorLoginForm')) {
    document.getElementById('doctorLoginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('doctorEmail').value;
        const password = document.getElementById('doctorPassword').value;
        
        const doctor = doctors.find(d => d.email === email && d.password === password);
        
        if (doctor) {
            localStorage.setItem('currentDoctor', JSON.stringify(doctor));
            window.location.href = 'doctor-dashboard.html';
        } else {
            alert('Invalid email or password!');
        }
    });
}

// ==================== DOCTOR DASHBOARD ====================
if (window.location.pathname.includes('doctor-dashboard.html')) {
    currentDoctor = JSON.parse(localStorage.getItem('currentDoctor'));
    
    if (!currentDoctor) {
        window.location.href = 'doctor-login.html';
    }
    
    document.getElementById('doctorName').innerHTML = `Welcome, ${currentDoctor.name}`;
    displayDoctorAppointments();
}

function displayDoctorAppointments() {
    const appointments = JSON.parse(localStorage.getItem('appointments')) || [];
    const doctorAppointments = appointments.filter(a => a.doctorName === currentDoctor.name);
    const container = document.getElementById('doctorAppointments');
    
    if (doctorAppointments.length === 0) {
        container.innerHTML = '<div class="alert alert-info">No appointment requests for you.</div>';
        return;
    }
    
    container.innerHTML = doctorAppointments.map(app => `
        <div class="appointment-card card mb-3" style="border-left-color: ${getStatusColor(app.status)}">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="mb-2">Patient: ${app.clientName}</h6>
                        <p class="mb-1"><strong>Email:</strong> ${app.clientEmail}</p>
                        <p class="mb-1"><strong>Phone:</strong> ${app.clientPhone}</p>
                        <p class="mb-1"><strong>Date:</strong> ${app.date}</p>
                        <p class="mb-1"><strong>Time:</strong> ${app.time}</p>
                        <p class="mb-1"><strong>Reason:</strong> ${app.reason || 'Not specified'}</p>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <span class="badge status-${app.status.toLowerCase()} mb-2">${app.status}</span>
                        ${app.status === 'Pending' ? `
                            <div class="mt-2">
                                <button class="btn btn-success btn-sm me-2" onclick="updateAppointmentStatus(${app.id}, 'Accept')">Accept</button>
                                <button class="btn btn-danger btn-sm" onclick="updateAppointmentStatus(${app.id}, 'Reject')">Reject</button>
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

function updateAppointmentStatus(appointmentId, status) {
    let appointments = JSON.parse(localStorage.getItem('appointments'));
    appointments = appointments.map(app => {
        if (app.id === appointmentId) {
            app.status = status;
        }
        return app;
    });
    localStorage.setItem('appointments', JSON.stringify(appointments));
    displayDoctorAppointments();
}

// ==================== HELPER FUNCTIONS ====================
function getStatusColor(status) {
    switch(status.toLowerCase()) {
        case 'pending': return '#ffc107';
        case 'accept': return '#28a745';
        case 'reject': return '#dc3545';
        default: return '#6c757d';
    }
}

function logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('currentDoctor');
    localStorage.removeItem('isAdminLoggedIn');
    window.location.href = 'index.html';
}

// Initialize data on first load
if (!localStorage.getItem('initialized')) {
    // Create demo client
    const demoClient = {
        id: 1,
        name: 'John Doe',
        email: 'john@example.com',
        phone: '1234567890',
        password: '123'
    };
    
    if (!localStorage.getItem('clients')) {
        localStorage.setItem('clients', JSON.stringify([demoClient]));
    }
    
    localStorage.setItem('initialized', 'true');
}