function registerStudent(event) {
    event.preventDefault();
    
    const name = document.getElementById('name')?.value;
    const email = document.getElementById('email')?.value;
    const password = document.getElementById('password')?.value;
    const confirmPassword = document.getElementById('confirmPassword')?.value;
    
    if (password !== confirmPassword) {
        showNotification('Passwords do not match!', 'danger');
        return false;
    }
    
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    
    if (students.find(s => s.email === email)) {
        showNotification('Email already registered!', 'danger');
        return false;
    }
    
    const newStudent = {
        id: Date.now(),
        name: name,
        email: email,
        password: password,
        enrolledCourses: [],
        quizScores: {},
        registeredAt: new Date().toISOString()
    };
    
    students.push(newStudent);
    localStorage.setItem('lms_students', JSON.stringify(students));
    
    showNotification('Registration successful! Please login.', 'success');
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 1500);
    
    return false;
}

// Student Login
function loginStudent(event) {
    event.preventDefault();
    
    const email = document.getElementById('email')?.value;
    const password = document.getElementById('password')?.value;
    
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    const student = students.find(s => s.email === email && s.password === password);
    
    if (student) {
        localStorage.setItem('current_student', JSON.stringify(student));
        showNotification('Login successful!', 'success');
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
    } else {
        showNotification('Invalid email or password!', 'danger');
    }
    
    return false;
}

// Admin Login
function loginAdmin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username')?.value;
    const password = document.getElementById('password')?.value;
    
    if (username === 'admin' && password === '123') {
        localStorage.setItem('admin_logged_in', 'true');
        localStorage.setItem('current_admin', JSON.stringify({ id: 'admin', name: 'Admin', role: 'admin' }));
        showNotification('Admin login successful!', 'success');
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
    } else {
        showNotification('Invalid admin credentials!', 'danger');
    }
    
    return false;
}

// Faculty Login
function loginFaculty(event) {
    event.preventDefault();
    
    const FacultyId = document.getElementById('FacultyId')?.value;
    const password = document.getElementById('password')?.value;
    
    const FacultyCredentials = {
        'vb': { id: 'vb', name: 'Vijay B', password: '123', role: 'Faculty' },
        'am': { id: 'am', name: 'Arun M', password: '123', role: 'Faculty' }
    };
    
    if (FacultyCredentials[FacultyId] && FacultyCredentials[FacultyId].password === password) {
        const Faculty = FacultyCredentials[FacultyId];
        localStorage.setItem('Faculty_logged_in', 'true');
        localStorage.setItem('current_Faculty', JSON.stringify(Faculty));
        showNotification(`Welcome ${Faculty.name}!`, 'success');
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
    } else {
        showNotification('Invalid Faculty ID or Password!', 'danger');
    }
    
    return false;
}

// Check Auth
function checkStudentAuth() {
    const currentStudent = localStorage.getItem('current_student');
    if (!currentStudent) {
        window.location.href = '../student/login.html';
        return null;
    }
    return JSON.parse(currentStudent);
}

function checkAdminAuth() {
    const adminLoggedIn = localStorage.getItem('admin_logged_in');
    if (!adminLoggedIn) {
        window.location.href = '../admin/login.html';
        return false;
    }
    return true;
}

function checkFacultyAuth() {
    const FacultyLoggedIn = localStorage.getItem('Faculty_logged_in');
    if (!FacultyLoggedIn) {
        window.location.href = '../Faculty/login.html';
        return null;
    }
    return JSON.parse(localStorage.getItem('current_Faculty'));
}

// Get current user role
function getCurrentUserRole() {
    if (localStorage.getItem('admin_logged_in')) return 'admin';
    if (localStorage.getItem('Faculty_logged_in')) return 'Faculty';
    if (localStorage.getItem('current_student')) return 'student';
    return null;
}

// Logout
function logout() {
    localStorage.removeItem('current_student');
    localStorage.removeItem('admin_logged_in');
    localStorage.removeItem('current_admin');
    localStorage.removeItem('Faculty_logged_in');
    localStorage.removeItem('current_Faculty');
    
    showNotification('Logged out successfully! Redirecting...', 'success');
    
    setTimeout(() => {
        window.location.href = '../index.html';
    }, 1000);
}

// ============ COURSE MANAGEMENT ============

// Get all courses (admin sees all, Faculty sees only their own)
function getAllCourses() {
    const allCourses = JSON.parse(localStorage.getItem('lms_courses')) || [];
    const currentFaculty = JSON.parse(localStorage.getItem('current_Faculty'));
    
    // If Faculty logged in, filter courses by FacultyId
    if (currentFaculty && currentFaculty.role === 'Faculty') {
        return allCourses.filter(c => c.createdBy === currentFaculty.id);
    }
    
    return allCourses;
}

// Get all courses for admin (no filter)
function getAllCoursesAdmin() {
    return JSON.parse(localStorage.getItem('lms_courses')) || [];
}

function saveCourse(course) {
    const courses = getAllCoursesAdmin();
    courses.push(course);
    localStorage.setItem('lms_courses', JSON.stringify(courses));
    return course;
}

function updateCourse(courseId, updatedCourse) {
    const courses = getAllCoursesAdmin();
    const index = courses.findIndex(c => c.id === courseId);
    if (index !== -1) {
        courses[index] = updatedCourse;
        localStorage.setItem('lms_courses', JSON.stringify(courses));
    }
}

function deleteCourse(courseId) {
    let courses = getAllCoursesAdmin();
    const courseToDelete = courses.find(c => c.id === courseId);
    courses = courses.filter(c => c.id !== courseId);
    localStorage.setItem('lms_courses', JSON.stringify(courses));
    
    // Remove course from student enrollments
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    students.forEach(student => {
        if (student.enrolledCourses) {
            student.enrolledCourses = student.enrolledCourses.filter(id => id !== courseId);
        }
        if (student.quizScores && student.quizScores[courseId]) {
            delete student.quizScores[courseId];
        }
    });
    localStorage.setItem('lms_students', JSON.stringify(students));
    
    return courseToDelete;
}

// ============ Faculty COURSE CREATION ============

function createFacultyCourse(courseData, questions) {
    const Faculty = JSON.parse(localStorage.getItem('current_Faculty'));
    
    const newCourse = {
        id: Date.now(),
        title: courseData.title,
        description: courseData.description,
        category: courseData.category,
        difficulty: courseData.difficulty,
        duration: courseData.duration,
        thumbnail: courseData.thumbnail || '',
        learningOutcomes: courseData.learningOutcomes || [],
        prerequisites: courseData.prerequisites || [],
        createdBy: Faculty.id,
        createdByName: Faculty.name,
        createdAt: new Date().toISOString(),
        enrolledStudents: [],
        rating: 0,
        questions: questions.map((q, idx) => ({
            id: idx + 1,
            question: q.question,
            options: q.options,
            answer: q.answer
        })),
        // Add quiz property for compatibility with student view
        quiz: questions.map((q, idx) => ({
            id: idx + 1,
            question: q.question,
            options: q.options,
            answer: q.answer
        }))
    };
    
    const courses = getAllCoursesAdmin();
    courses.push(newCourse);
    localStorage.setItem('lms_courses', JSON.stringify(courses));
    
    console.log('Course created:', newCourse);
    console.log('All courses:', getAllCoursesAdmin());
    
    return newCourse;
}

// ============ QUIZ FUNCTIONS ============

function saveQuizScore(studentId, courseId, score, totalQuestions, answers) {
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    const studentIndex = students.findIndex(s => s.id === studentId);
    
    if (studentIndex !== -1) {
        if (!students[studentIndex].quizScores) {
            students[studentIndex].quizScores = {};
        }
        if (!students[studentIndex].quizScores[courseId]) {
            students[studentIndex].quizScores[courseId] = [];
        }
        
        students[studentIndex].quizScores[courseId].push({
            score: score,
            total: totalQuestions,
            percentage: (score / totalQuestions) * 100,
            answers: answers,
            date: new Date().toISOString()
        });
        
        localStorage.setItem('lms_students', JSON.stringify(students));
        
        const currentStudent = JSON.parse(localStorage.getItem('current_student'));
        if (currentStudent && currentStudent.id === studentId) {
            localStorage.setItem('current_student', JSON.stringify(students[studentIndex]));
        }
    }
}

function getStudentQuizScores(studentId, courseId) {
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    const student = students.find(s => s.id === studentId);
    if (student && student.quizScores && student.quizScores[courseId]) {
        return student.quizScores[courseId];
    }
    return [];
}

function enrollStudentInCourse(studentId, courseId) {
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    const studentIndex = students.findIndex(s => s.id === studentId);
    
    if (studentIndex !== -1) {
        if (!students[studentIndex].enrolledCourses) {
            students[studentIndex].enrolledCourses = [];
        }
        if (!students[studentIndex].enrolledCourses.includes(courseId)) {
            students[studentIndex].enrolledCourses.push(courseId);
            
            // Also update the course's enrolledStudents array
            const courses = getAllCoursesAdmin();
            const courseIndex = courses.findIndex(c => c.id === courseId);
            if (courseIndex !== -1) {
                if (!courses[courseIndex].enrolledStudents) {
                    courses[courseIndex].enrolledStudents = [];
                }
                if (!courses[courseIndex].enrolledStudents.includes(studentId)) {
                    courses[courseIndex].enrolledStudents.push(studentId);
                }
                localStorage.setItem('lms_courses', JSON.stringify(courses));
            }
            
            localStorage.setItem('lms_students', JSON.stringify(students));
            
            const currentStudent = JSON.parse(localStorage.getItem('current_student'));
            if (currentStudent && currentStudent.id === studentId) {
                localStorage.setItem('current_student', JSON.stringify(students[studentIndex]));
            }
            return true;
        }
    }
    return false;
}

// ============ UTILITY FUNCTIONS ============

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function showNotification(message, type = 'info') {
    const existingNotifications = document.querySelectorAll('.alert-notification');
    existingNotifications.forEach(notification => notification.remove());
    
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show alert-notification`;
    notification.style.cssText = 'position: fixed; top: 80px; right: 20px; z-index: 9999; min-width: 300px; animation: slideInRight 0.3s ease; box-shadow: 0 5px 15px rgba(0,0,0,0.2);';
    notification.innerHTML = `
        <i class="bi ${type === 'success' ? 'bi-check-circle' : type === 'danger' ? 'bi-exclamation-triangle' : 'bi-info-circle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification && notification.remove) {
            notification.remove();
        }
    }, 3000);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Initialize demo data with some sample courses if none exist
function initializeDemoData() {
    let students = JSON.parse(localStorage.getItem('lms_students')) || [];
    if (students.length === 0) {
        const demoStudent = {
            id: Date.now(),
            name: 'Demo Student',
            email: 'student@example.com',
            password: '123456',
            enrolledCourses: [],
            quizScores: {},
            registeredAt: new Date().toISOString()
        };
        students.push(demoStudent);
        localStorage.setItem('lms_students', JSON.stringify(students));
    }
    
    // Check if there are any courses, if not add sample courses for demo
    let courses = getAllCoursesAdmin();
    if (courses.length === 0) {
        const sampleCourses = [
            {
                id: Date.now() + 1,
                title: "Web Development Bootcamp",
                description: "Learn HTML, CSS, JavaScript, and React from scratch. Build real-world projects and become a full-stack developer.",
                category: "Web Development",
                difficulty: "Beginner",
                duration: "40 hours",
                thumbnail: "",
                createdBy: "admin",
                createdByName: "Admin",
                createdAt: new Date().toISOString(),
                enrolledStudents: [],
                rating: 4.8,
                questions: [
                    { id: 1, question: "What does HTML stand for?", options: ["Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Markup Language", "Home Tool Markup Language"], answer: 0 },
                    { id: 2, question: "Which CSS property is used to change text color?", options: ["text-color", "font-color", "color", "text-style"], answer: 2 },
                    { id: 3, question: "What does CSS stand for?", options: ["Creative Style Sheets", "Computer Style Sheets", "Cascading Style Sheets", "Colorful Style Sheets"], answer: 2 },
                    { id: 4, question: "Which JavaScript keyword is used to declare a variable?", options: ["var", "let", "const", "All of the above"], answer: 3 },
                    { id: 5, question: "What is React?", options: ["A JavaScript library for building UI", "A programming language", "A database", "A server framework"], answer: 0 }
                ],
                quiz: [
                    { id: 1, question: "What does HTML stand for?", options: ["Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Markup Language", "Home Tool Markup Language"], answer: 0 },
                    { id: 2, question: "Which CSS property is used to change text color?", options: ["text-color", "font-color", "color", "text-style"], answer: 2 },
                    { id: 3, question: "What does CSS stand for?", options: ["Creative Style Sheets", "Computer Style Sheets", "Cascading Style Sheets", "Colorful Style Sheets"], answer: 2 },
                    { id: 4, question: "Which JavaScript keyword is used to declare a variable?", options: ["var", "let", "const", "All of the above"], answer: 3 },
                    { id: 5, question: "What is React?", options: ["A JavaScript library for building UI", "A programming language", "A database", "A server framework"], answer: 0 }
                ]
            },
            {
                id: Date.now() + 2,
                title: "Python Programming Masterclass",
                description: "Master Python from basics to advanced. Learn data structures, OOP, and build real applications.",
                category: "Programming",
                difficulty: "Beginner",
                duration: "35 hours",
                thumbnail: "",
                createdBy: "admin",
                createdByName: "Admin",
                createdAt: new Date().toISOString(),
                enrolledStudents: [],
                rating: 4.7,
                questions: [
                    { id: 1, question: "What is the correct file extension for Python files?", options: [".pyth", ".pt", ".py", ".p"], answer: 2 },
                    { id: 2, question: "Which function is used to output text in Python?", options: ["output()", "print()", "console.log()", "echo()"], answer: 1 },
                    { id: 3, question: "What is the correct way to create a function in Python?", options: ["function myFunction():", "def myFunction():", "create myFunction():", "new myFunction():"], answer: 1 },
                    { id: 4, question: "What is the result of 2**3 in Python?", options: ["5", "6", "8", "9"], answer: 2 },
                    { id: 5, question: "Which keyword is used to define a class in Python?", options: ["class", "Class", "define", "struct"], answer: 0 }
                ],
                quiz: [
                    { id: 1, question: "What is the correct file extension for Python files?", options: [".pyth", ".pt", ".py", ".p"], answer: 2 },
                    { id: 2, question: "Which function is used to output text in Python?", options: ["output()", "print()", "console.log()", "echo()"], answer: 1 },
                    { id: 3, question: "What is the correct way to create a function in Python?", options: ["function myFunction():", "def myFunction():", "create myFunction():", "new myFunction():"], answer: 1 },
                    { id: 4, question: "What is the result of 2**3 in Python?", options: ["5", "6", "8", "9"], answer: 2 },
                    { id: 5, question: "Which keyword is used to define a class in Python?", options: ["class", "Class", "define", "struct"], answer: 0 }
                ]
            }
        ];
        
        courses = sampleCourses;
        localStorage.setItem('lms_courses', JSON.stringify(courses));
        console.log('Sample courses added to localStorage');
    }
}

// CSS animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .alert-notification {
        cursor: pointer;
    }
    
    .alert-notification:hover {
        transform: translateX(-5px);
        transition: transform 0.2s;
    }
`;
document.head.appendChild(style);

document.addEventListener('DOMContentLoaded', function() {
    initializeDemoData();
});


// ============ AI COURSE GENERATION FOR ADMIN ============

// AI-Powered Course Content Generator with configurable questions
class AICourseGenerator {
    static async generateFullCourse(courseName, questionCount = 10, difficulty = 'Intermediate', category = null) {
        // Simulate AI processing
        return new Promise((resolve) => {
            setTimeout(() => {
                const course = this.createCourseFromName(courseName, questionCount, difficulty, category);
                resolve(course);
            }, 1500);
        });
    }
    
    static createCourseFromName(courseName, questionCount, difficulty, category) {
        const topics = this.extractTopics(courseName);
        const description = this.generateDescription(courseName, topics);
        const finalCategory = category || this.detectCategory(courseName);
        const finalDifficulty = difficulty || this.detectDifficulty(courseName);
        const questions = this.generateAIQuestions(courseName, topics, finalDifficulty, questionCount);
        const learningOutcomes = this.generateLearningOutcomes(courseName, topics);
        const prerequisites = this.generatePrerequisites(courseName);
        const duration = this.estimateDuration(questionCount);
        
        return {
            title: courseName,
            description: description,
            category: finalCategory,
            difficulty: finalDifficulty,
            questions: questions,
            quiz: questions, // Add quiz property for compatibility
            learningOutcomes: learningOutcomes,
            prerequisites: prerequisites,
            topics: topics,
            duration: duration,
            rating: 4.5,
            enrolledStudents: 0
        };
    }
    
    static extractTopics(courseName) {
        const keywords = {
            'web': ['HTML', 'CSS', 'JavaScript', 'React', 'Responsive Design', 'Web APIs', 'Node.js', 'Express'],
            'python': ['Variables', 'Functions', 'OOP', 'Libraries', 'Data Structures', 'File Handling', 'Decorators', 'Modules'],
            'javascript': ['ES6', 'DOM Manipulation', 'Async/Await', 'Promises', 'Arrays', 'Objects', 'Closures', 'Events'],
            'react': ['Components', 'Props', 'State', 'Hooks', 'Redux', 'Router', 'Context API', 'Lifecycle'],
            'machine learning': ['Supervised Learning', 'Unsupervised Learning', 'Neural Networks', 'TensorFlow', 'Classification', 'Regression', 'Clustering'],
            'data science': ['Pandas', 'NumPy', 'Matplotlib', 'Machine Learning', 'Statistics', 'Data Visualization', 'SQL'],
            'ai': ['Neural Networks', 'Deep Learning', 'NLP', 'Computer Vision', 'Transformers', 'GPT', 'LLMs'],
            'business': ['Marketing', 'Finance', 'Strategy', 'Leadership', 'Operations', 'Analytics', 'Management'],
            'design': ['UI Design', 'UX Research', 'Figma', 'Prototyping', 'Color Theory', 'Typography', 'Wireframing'],
            'marketing': ['SEO', 'Social Media', 'Content Strategy', 'Analytics', 'Email Marketing', 'PPC', 'Branding']
        };
        
        const lowerName = courseName.toLowerCase();
        let extractedTopics = [];
        
        for (const [key, topics] of Object.entries(keywords)) {
            if (lowerName.includes(key)) {
                extractedTopics = topics.slice(0, 8);
                break;
            }
        }
        
        if (extractedTopics.length === 0) {
            extractedTopics = [
                'Introduction to ' + courseName,
                'Core Concepts and Fundamentals',
                'Advanced Techniques',
                'Practical Applications',
                'Best Practices and Standards',
                'Real-world Projects',
                'Industry Trends',
                'Expert Tips and Tricks'
            ];
        }
        
        return extractedTopics;
    }
    
    static generateDescription(courseName, topics) {
        const descriptions = [
            `Master ${courseName} from scratch with our comprehensive AI-powered course designed for beginners and professionals.`,
            `Learn ${courseName} through hands-on projects and real-world applications. Perfect for career advancement.`,
            `Become an expert in ${courseName} with this all-in-one course covering everything from basics to advanced concepts.`,
            `Unlock your potential with ${courseName}. This course includes practical exercises, quizzes, and real projects.`,
            `Transform your career with our ${courseName} course. Industry-ready curriculum designed by experts.`
        ];
        
        let description = descriptions[Math.floor(Math.random() * descriptions.length)];
        description += ` You'll learn: ${topics.slice(0, 4).join(', ')}, and much more!`;
        
        return description;
    }
    
    static detectCategory(courseName) {
        const lower = courseName.toLowerCase();
        if (lower.includes('web') || lower.includes('html') || lower.includes('css') || lower.includes('javascript') || lower.includes('react')) {
            return 'Web Development';
        } else if (lower.includes('python') || lower.includes('java') || lower.includes('programming') || lower.includes('code')) {
            return 'Programming';
        } else if (lower.includes('data') || lower.includes('machine') || lower.includes('ai') || lower.includes('learning')) {
            return 'Data Science';
        } else if (lower.includes('business') || lower.includes('management')) {
            return 'Business';
        } else if (lower.includes('design') || lower.includes('ui') || lower.includes('ux')) {
            return 'Design';
        } else if (lower.includes('marketing')) {
            return 'Marketing';
        }
        return 'Technology';
    }
    
    static detectDifficulty(courseName) {
        const lower = courseName.toLowerCase();
        if (lower.includes('advanced') || lower.includes('expert') || lower.includes('master')) {
            return 'Advanced';
        } else if (lower.includes('intermediate') || lower.includes('professional')) {
            return 'Intermediate';
        }
        return 'Beginner';
    }
    
    static generateAIQuestions(courseName, topics, difficulty, questionCount) {
        const questions = [];
        const questionTemplates = [
            { text: "What is the primary purpose of {topic} in {course}?", type: "concept" },
            { text: "Which of the following best describes {topic}?", type: "definition" },
            { text: "How does {topic} improve efficiency in {course}?", type: "application" },
            { text: "What are the key benefits of using {topic}?", type: "benefits" },
            { text: "Which statement about {topic} is correct?", type: "factual" },
            { text: "What is the most common use case for {topic}?", type: "use_case" },
            { text: "How do you implement {topic} effectively?", type: "implementation" },
            { text: "What are the best practices for {topic}?", type: "best_practice" },
            { text: "Which tool/framework is commonly used with {topic}?", type: "tool" },
            { text: "What problem does {topic} solve in {course}?", type: "problem_solving" }
        ];
        
        for (let i = 0; i < questionCount; i++) {
            const topicIndex = i % topics.length;
            const topic = topics[topicIndex];
            const templateIndex = i % questionTemplates.length;
            const template = questionTemplates[templateIndex];
            
            let questionText = template.text
                .replace('{topic}', topic)
                .replace('{course}', courseName);
            
            const options = this.generateOptionsForTopic(topic, courseName, difficulty, i);
            const correctAnswer = Math.floor(Math.random() * 4);
            
            questions.push({
                id: i + 1,
                question: questionText,
                options: options,
                answer: correctAnswer
            });
        }
        
        return questions;
    }
    
    static generateOptionsForTopic(topic, courseName, difficulty, seed) {
        const optionSets = [
            [
                `Understanding ${topic} fundamentals is crucial for success`,
                `Advanced ${topic} techniques are more important`,
                `${topic} is optional in ${courseName}`,
                `${topic} doesn't affect the learning outcome`
            ],
            [
                `Best practices include regular practice and implementation`,
                `Only theoretical knowledge matters for ${topic}`,
                `${topic} can be ignored in real-world scenarios`,
                `Memorization is the key to mastering ${topic}`
            ],
            [
                `Real-world applications demonstrate ${topic} effectively`,
                `${topic} is only theoretical with no practical use`,
                `Case studies are irrelevant for ${topic}`,
                `Hands-on practice is not recommended for ${topic}`
            ],
            [
                `Proper implementation of ${topic} leads to better results`,
                `${topic} doesn't require any planning`,
                `Random approach works best for ${topic}`,
                `${topic} has no defined best practices`
            ]
        ];
        
        const setIndex = seed % optionSets.length;
        return optionSets[setIndex];
    }
    
    static generateLearningOutcomes(courseName, topics) {
        return topics.slice(0, 5).map(topic => `Master ${topic} concepts and apply them in real projects`);
    }
    
    static generatePrerequisites(courseName) {
        const lower = courseName.toLowerCase();
        if (lower.includes('advanced') || lower.includes('expert')) {
            return ['Basic understanding of programming', 'Familiarity with core concepts', 'Computer with internet access', 'Dedication to learn'];
        }
        return ['No prior knowledge required', 'Willingness to learn', 'Computer with internet access', 'Basic computer skills'];
    }
    
    static estimateDuration(questionCount) {
        const hours = Math.ceil(questionCount / 2);
        return `${hours} hours`;
    }
}

// Admin AI Course Creation with configurable questions
async function createAICourseWithOptions(courseName, questionCount = 10, difficulty = 'Intermediate', category = null) {
    showNotification('🤖 AI is generating your course...', 'info');
    
    const generated = await AICourseGenerator.generateFullCourse(courseName, questionCount, difficulty, category);
    
    const newCourse = {
        id: Date.now(),
        title: generated.title,
        description: generated.description,
        category: generated.category,
        difficulty: generated.difficulty,
        questions: generated.questions,
        quiz: generated.questions, // Add quiz property
        instructor: 'AI Instructor',
        thumbnail: '',
        learningOutcomes: generated.learningOutcomes,
        prerequisites: generated.prerequisites,
        duration: generated.duration,
        createdBy: 'admin',
        createdByName: 'Admin',
        createdAt: new Date().toISOString(),
        enrolledStudents: [],
        rating: 4.5
    };
    
    const courses = getAllCoursesAdmin();
    courses.push(newCourse);
    localStorage.setItem('lms_courses', JSON.stringify(courses));
    
    showNotification(`✅ Course "${courseName}" created successfully with ${questionCount} AI questions!`, 'success');
    
    return newCourse;
}

// Legacy function for compatibility
async function createAICourse(courseName) {
    return await createAICourseWithOptions(courseName, 10, 'Intermediate', null);
}


// Export functions
window.logout = logout;
window.registerStudent = registerStudent;
window.loginStudent = loginStudent;
window.loginAdmin = loginAdmin;
window.loginFaculty = loginFaculty;
window.enrollStudentInCourse = enrollStudentInCourse;
window.getAllCourses = getAllCourses;
window.getAllCoursesAdmin = getAllCoursesAdmin;
window.deleteCourse = deleteCourse;
window.showNotification = showNotification;
window.escapeHtml = escapeHtml;
window.formatDate = formatDate;
window.createFacultyCourse = createFacultyCourse;
window.checkFacultyAuth = checkFacultyAuth;
window.checkAdminAuth = checkAdminAuth;
window.checkStudentAuth = checkStudentAuth;
window.getCurrentUserRole = getCurrentUserRole;